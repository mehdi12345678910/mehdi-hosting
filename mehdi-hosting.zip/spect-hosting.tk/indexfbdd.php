<?xml version="1.0" encoding="utf-8"?>
            <rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
                <channel>
                    <atom:link href="https://b9h-hosting.tk/index.php?rp=/announcements/rss" rel="self" type="application/rss+xml" />
                    <title><![CDATA[Spect Hosting]]></title>
                    <description><![CDATA[Spect Hosting Сповіщення RSS]]></description>
                    <link>https://b9h-hosting.tk/index.php?rp=/announcements</link>
                    
<item>
    <title><![CDATA[تابعنا على تويتر]]></title>
    <link>https://b9h-hosting.tk/index.php?rp=/announcements/1</link>
    <guid>https://b9h-hosting.tk/index.php?rp=/announcements/1</guid>
    <pubDate>Tue, 14 Sept 2021 14:02:00 +0000</pubDate>
    <description><![CDATA[<p style="box-sizing: border-box; margin: 0px 0px 10px; color: #ffffff; font-family: Karla, sans-serif; font-size: 13px; background-color: #292c3e;">يمكنك متابعتنا على تويتر لمشاهدة اخر اخبار الاتصال وايضاً الدعم الفني</p>
<p style="box-sizing: border-box; margin: 0px 0px 10px; color: #ffffff; font-family: Karla, sans-serif; font-size: 13px; background-color: #292c3e;">https://twitter.com/teamb9h</p>]]></description>
</item>
                </channel>
            </rss>